javac -d .  Serveur/*.java
javac -d . Client/*.java
