package Serveur;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.*;

public class ServeurPrincipal {
    private static boolean exceptionSurvenue = false;

    public static void main(String[] args) {
        String fichierConfig = "config/configPrincipal.txt"; // Chemin du fichier de configuration
        Map<String, String> config = ConfigReader.lireConfig(fichierConfig);
        int port = Integer.parseInt(config.get("port"));
        int portListe = Integer.parseInt(config.get("portListe"));
        int portTelechargement = Integer.parseInt(config.get("portTelechargement"));
        int portSuppression = Integer.parseInt(config.get("portSuppression"));
        ArrayList<String> adressesEsclaves = new ArrayList<>();
        ArrayList<Integer> portsEsclaves = new ArrayList<>();

        try (ServerSocket serveurSocket = new ServerSocket(port)) {
            System.out.println("Serveur principal en attente sur le port " + port);

            new Thread(() -> ecouterEsclaves(12349, portsEsclaves, adressesEsclaves)).start();
            new Thread(() -> gererDemandesListeFichiers(portListe)).start();
            new Thread(() -> gererDemandesTelechargementFichiers(portTelechargement, adressesEsclaves, portsEsclaves))
                    .start();
            new Thread(() -> gererDemandesSuppressionFichiers(portSuppression, adressesEsclaves, portsEsclaves))
                    .start();

            while (true) {
                try (Socket socketClient = serveurSocket.accept()) {
                    System.out.println("Client connecté : " + socketClient.getInetAddress());

                    // Gérer la réception du fichier
                    gererReceptionFichier(socketClient, portsEsclaves, adressesEsclaves);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void ecouterEsclaves(int portDiffusion, ArrayList<Integer> portsEsclaves,
            ArrayList<String> adressesEsclaves) {
        try (DatagramSocket socket = new DatagramSocket(portDiffusion, InetAddress.getByName("0.0.0.0"))) {
            socket.setBroadcast(true); // Permet l'écoute en diffusion
            byte[] buffer = new byte[1024];
            System.out.println("En attente de messages de diffusion sur le port " + portDiffusion);

            while (true) {
                DatagramPacket paquet = new DatagramPacket(buffer, buffer.length);
                socket.receive(paquet); // Attendre un message de diffusion
                String message = new String(paquet.getData(), 0, paquet.getLength());
                System.out.println("Message reçu : " + message);

                // Extraire les informations comme le port et la partition
                String[] parties = message.split(" ");
                String port = parties[6];
                if (!portsEsclaves.contains(Integer.parseInt(port))) {
                    portsEsclaves.add(Integer.parseInt(port));
                }

                String adresseIp = parties[4];
                adressesEsclaves.add(adresseIp);

                System.out.println("Serveur esclave trouvé sur le port : " + port);
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de l'écoute de la diffusion : " + e.getMessage());
        }
    }

    private static void gererDemandesSuppressionFichiers(int portSuppression, ArrayList<String> adressesEsclaves,
            ArrayList<Integer> portsEsclaves) {
        try (ServerSocket socketSuppression = new ServerSocket(portSuppression)) {
            System.out.println("Serveur de suppression en attente sur le port " + portSuppression);

            while (true) {
                try (Socket socketClient = socketSuppression.accept();
                        DataInputStream entree = new DataInputStream(socketClient.getInputStream());
                        DataOutputStream sortie = new DataOutputStream(socketClient.getOutputStream())) {

                    String nomFichier = entree.readUTF();
                    System.out.println("Demande de suppression pour : " + nomFichier);

                    boolean succes = true;

                    for (int i = 0; i < portsEsclaves.size(); i++) {
                        String nomPartie = ajouterSuffixePartie(nomFichier, i + 1);
                        if (!supprimerPartieDepuisEsclave(nomPartie, adressesEsclaves.get(i), portsEsclaves.get(i))) {
                            succes = false;
                            System.err.println("Échec de la suppression de la partie : " + nomPartie);
                        }
                    }

                    if (succes) {
                        mettreAJourJournalApresSuppression(nomFichier);
                        sortie.writeUTF("SUCCES");
                        System.out.println("Fichier " + nomFichier + " supprimé avec succès.");
                    } else {
                        sortie.writeUTF("ECHEC");
                        System.err.println("Échec de la suppression du fichier complet : " + nomFichier);
                    }

                } catch (IOException e) {
                    System.err.println("Erreur lors de la suppression : " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur de suppression : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void gererDemandesTelechargementFichiers(int portTelechargement, ArrayList<String> adressesEsclaves,
            ArrayList<Integer> portsEsclaves) {
        try (ServerSocket socketServeurTelechargement = new ServerSocket(portTelechargement)) {
            System.out.println("Serveur de téléchargement en attente sur le port " + portTelechargement);

            while (true) {
                try (Socket socketClient = socketServeurTelechargement.accept();
                        DataInputStream entree = new DataInputStream(socketClient.getInputStream());
                        DataOutputStream sortie = new DataOutputStream(socketClient.getOutputStream())) {

                    // Lire le nom du fichier demandé
                    String fichierDemande = entree.readUTF();
                    System.out.println("Demande de téléchargement pour le fichier : " + fichierDemande);

                    // Récupérer et envoyer chaque partie du fichier
                    for (int i = 0; i < portsEsclaves.size(); i++) {
                        String nomPartie = ajouterSuffixePartie(fichierDemande, i + 1);
                        byte[] donneesPartie = recupererPartieDepuisEsclave(nomPartie, adressesEsclaves.get(i),
                                portsEsclaves.get(i));

                        if (donneesPartie == null) {
                            sortie.writeUTF("NON_TROUVE");
                            System.err.println("Partie introuvable : " + nomPartie);
                            return;
                        }

                        sortie.write(donneesPartie);
                        System.out.println("Partie " + nomPartie + " envoyée au client.");
                    }

                    sortie.flush();
                    System.out.println("Fichier complet combiné et envoyé au client.");
                } catch (IOException e) {
                    System.err.println("Erreur lors du téléchargement du fichier : " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur de téléchargement : " + e.getMessage());
        }
    }

    private static void gererReceptionFichier(Socket socketClient, ArrayList<Integer> listeOffsets,
            ArrayList<String> listeParties) {
        try (DataInputStream entree = new DataInputStream(socketClient.getInputStream());
                DataOutputStream sortie = new DataOutputStream(socketClient.getOutputStream())) {

            System.out.println(
                    "Début de la réception du fichier depuis le client " + socketClient.getRemoteSocketAddress());

            // Lire le nom du fichier envoyé par le client
            String nomFichier = entree.readUTF();
            System.out.println("Nom du fichier reçu : " + nomFichier);

            // Lire le nombre de parties
            int nombreParties = entree.readInt();
            System.out.println("Nombre de parties reçues : " + nombreParties);

            for (int i = 0; i < nombreParties; i++) {
                // Lire les informations pour chaque partie
                int offset = entree.readInt();
                listeOffsets.add(offset);

                String nomPartie = entree.readUTF();
                listeParties.add(nomPartie);

                int taillePartie = entree.readInt();
                byte[] donneesPartie = new byte[taillePartie];
                entree.readFully(donneesPartie);

                System.out.println("Partie " + nomPartie + " reçue avec un offset de " + offset + " et une taille de "
                        + taillePartie);

                // Sauvegarder la partie reçue localement
                sauvegarderPartieLocalement(nomPartie, donneesPartie);
            }

            // Confirmation de réception au client
            sortie.writeUTF("RECEPTION_OK");
            sortie.flush();

            System.out.println("Réception du fichier terminée pour le client " + socketClient.getRemoteSocketAddress());

        } catch (IOException e) {
            System.err.println("Erreur lors de la réception du fichier : " + e.getMessage());
        }
    }

    private static void sauvegarderPartieLocalement(String nomPartie, byte[] donnees) {
        try (FileOutputStream fos = new FileOutputStream(nomPartie)) {
            fos.write(donnees);
            System.out.println("Partie " + nomPartie + " sauvegardée localement.");
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde de la partie " + nomPartie + " : " + e.getMessage());
        }
    }

    private static void mettreAJourJournalApresSuppression(String nomFichier) {
        File fichierJournal = new File("log/journal.txt");
        File fichierTemporaire = new File("log/temp_journal.txt");

        try (BufferedReader lecteur = new BufferedReader(new FileReader(fichierJournal));
                BufferedWriter ecrivain = new BufferedWriter(new FileWriter(fichierTemporaire))) {

            String ligne;
            while ((ligne = lecteur.readLine()) != null) {
                if (!ligne.trim().equals(nomFichier)) {
                    ecrivain.write(ligne);
                    ecrivain.newLine();
                }
            }

        } catch (IOException e) {
            System.err.println("Erreur lors de la mise à jour du journal : " + e.getMessage());
            e.printStackTrace();
            return;
        }

        if (!fichierJournal.delete()) {
            System.err.println("Impossible de supprimer l'ancien journal.");
            return;
        }

        if (!fichierTemporaire.renameTo(fichierJournal)) {
            System.err.println("Impossible de renommer le fichier temporaire en journal.txt.");
        } else {
            System.out.println("Journal mis à jour avec succès.");
        }
    }

    private static boolean supprimerPartieDepuisEsclave(String nomPartie, String adresseEsclave, int portEsclave) {
        try (Socket socketEsclave = new Socket(adresseEsclave, portEsclave);
                DataOutputStream sortie = new DataOutputStream(socketEsclave.getOutputStream());
                DataInputStream entree = new DataInputStream(socketEsclave.getInputStream())) {

            sortie.writeUTF("SUPPRIMER_PARTIE");
            sortie.writeUTF(nomPartie);

            String reponse = entree.readUTF();
            return "SUCCES".equals(reponse);

        } catch (IOException e) {
            System.err.println("Erreur lors de la suppression de la partie sur l'esclave : " + e.getMessage());
            return false;
        }
    }

    private static byte[] recupererPartieDepuisEsclave(String nomPartie, String adresseEsclave, int portEsclave) {
        try (Socket socketEsclave = new Socket(adresseEsclave, portEsclave);
                DataOutputStream sortie = new DataOutputStream(socketEsclave.getOutputStream());
                DataInputStream entree = new DataInputStream(socketEsclave.getInputStream())) {

            // Envoyer le nom de la partie demandée à l'esclave
            sortie.writeUTF(nomPartie);
            sortie.flush();
            System.out.println("Demande envoyée à l'esclave " + adresseEsclave + ":" + portEsclave + " pour la partie "
                    + nomPartie);

            // Lire la réponse
            String statut = entree.readUTF();
            if ("NON_TROUVE".equals(statut)) {
                System.err.println("L'esclave n'a pas trouvé la partie demandée : " + nomPartie);
                return null;
            }

            // Lire la taille de la partie
            int taillePartie = entree.readInt();
            byte[] donneesPartie = new byte[taillePartie];
            entree.readFully(donneesPartie);

            System.out.println("Partie " + nomPartie + " reçue depuis l'esclave.");
            return donneesPartie;

        } catch (IOException e) {
            System.err.println("Erreur lors de la récupération de la partie depuis l'esclave : " + e.getMessage());
            return null;
        }
    }

    private static String ajouterSuffixePartie(String nomFichier, int numeroPartie) {
        int indexPoint = nomFichier.lastIndexOf('.');
        if (indexPoint == -1) {
            return nomFichier + "_partie" + numeroPartie;
        }
        String nom = nomFichier.substring(0, indexPoint);
        String extension = nomFichier.substring(indexPoint);
        return nom + "_partie" + numeroPartie + extension;
    }

    private static void gererDemandesListeFichiers(int portListe) {
        try (ServerSocket socketListe = new ServerSocket(portListe)) {
            System.out.println("Serveur de liste en attente sur le port " + portListe);
            while (true) {
                try (Socket socketClient = socketListe.accept();
                        DataOutputStream sortie = new DataOutputStream(socketClient.getOutputStream());
                        BufferedReader lecteurJournal = new BufferedReader(new FileReader("log/journal.txt"))) {

                    String ligne;
                    while ((ligne = lecteurJournal.readLine()) != null) {
                        sortie.writeUTF(ligne);
                    }
                    sortie.writeUTF("FIN"); // Marqueur de fin
                } catch (FileNotFoundException e) {
                    System.err.println("Fichier journal introuvable. Aucun fichier à afficher.");
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur de liste : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
