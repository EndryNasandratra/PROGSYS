package Client;

import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class FileSenderClientGUI extends JFrame {
    private JTextField filePathField;
    private JButton browseButton, sendButton, refreshButton, downloadButton, deleteButton;
    private JComboBox<String> fileDropdown;
    private JFileChooser fileChooser;

    public FileSenderClientGUI() {
        setTitle("Gestionnaire de Fichiers Cloud");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(new Color(245, 245, 250));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Titre principal avec icône
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(new Color(245, 245, 250));
        JLabel titleLabel = new JLabel("Espace de Stockage Cloud");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(41, 128, 185));
        titlePanel.add(titleLabel);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        add(titlePanel, gbc);

        // Section des fichiers stockés
        JLabel storedLabel = new JLabel("Bibliothèque de fichiers :");
        storedLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        storedLabel.setForeground(new Color(52, 73, 94));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(storedLabel, gbc);

        // Dropdown amélioré
        fileDropdown = new JComboBox<>();
        fileDropdown.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        fileDropdown.setBackground(Color.WHITE);
        fileDropdown.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 0.7;
        add(fileDropdown, gbc);

        // Bouton Actualiser
        refreshButton = new JButton("Actualiser");
        styleButton(refreshButton, new Color(52, 152, 219));
        gbc.gridx = 2;
        gbc.weightx = 0.3;
        add(refreshButton, gbc);

        // Panel pour les boutons d'action
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        actionPanel.setBackground(new Color(245, 245, 250));

        downloadButton = new JButton("Télécharger");
        downloadButton.setEnabled(false);
        styleButton(downloadButton, new Color(46, 204, 113));
        actionPanel.add(downloadButton);

        deleteButton = new JButton("Supprimer");
        deleteButton.setEnabled(false);
        styleButton(deleteButton, new Color(231, 76, 60));
        actionPanel.add(deleteButton);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(actionPanel, gbc);

        // Section d'envoi de fichier
        JLabel uploadLabel = new JLabel("Nouveau fichier :");
        uploadLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        uploadLabel.setForeground(new Color(52, 73, 94));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        add(uploadLabel, gbc);

        filePathField = new JTextField();
        filePathField.setEditable(false);
        filePathField.setBackground(Color.WHITE);
        filePathField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)));
        filePathField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(filePathField, gbc);

        browseButton = new JButton("Sélectionner");
        styleButton(browseButton, new Color(52, 152, 219));
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(browseButton, gbc);

        sendButton = new JButton("Transférer");
        sendButton.setEnabled(false);
        styleButton(sendButton, new Color(155, 89, 182));
        gbc.gridx = 1;
        gbc.gridy = 5;
        add(sendButton, gbc);

        fileChooser = new JFileChooser();
        setBorderAroundComponents();

        // Actions
        browseButton.addActionListener(e -> chooseFile());
        sendButton.addActionListener(e -> sendFile());
        refreshButton.addActionListener(e -> fetchTransferredFiles());
        downloadButton.addActionListener(e -> downloadFile());
        deleteButton.addActionListener(e -> deleteFile());

        fileDropdown.addActionListener(e -> {
            boolean isSelected = fileDropdown.getSelectedItem() != null;
            downloadButton.setEnabled(isSelected);
            deleteButton.setEnabled(isSelected);
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void styleButton(JButton button, Color backgroundColor) {
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(backgroundColor.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
    }

    private void setBorderAroundComponents() {
        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(189, 195, 199), 2),
                "Espace Personnel", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 16), new Color(52, 73, 94));
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            border));
        panel.add(this.getContentPane());
        setContentPane(panel);
    }

    private void chooseFile() {
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            sendButton.setEnabled(true);
        }
    }

    private void sendFile() {
        String filePath = filePathField.getText();
        int port = 12345;

        try (Socket socket = new Socket("localhost", port);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             FileInputStream fileInputStream = new FileInputStream(filePath)) {

            File file = new File(filePath);
            long totalFileSize = file.length();

            out.writeUTF(file.getName());
            out.writeLong(totalFileSize);

            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }

            JOptionPane.showMessageDialog(this, 
                "Transfert réussi ! (" + totalFileSize + " octets)",
                "Succès", JOptionPane.INFORMATION_MESSAGE);

            filePathField.setText("");
            sendButton.setEnabled(false);
            fetchTransferredFiles();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur lors du transfert : " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fetchTransferredFiles() {
        int port = 12346;
        try (Socket socket = new Socket("localhost", port);
             DataInputStream in = new DataInputStream(socket.getInputStream())) {

            fileDropdown.removeAllItems();
            String fileName;
            while (!(fileName = in.readUTF()).equals("END")) {
                fileDropdown.addItem(fileName);
            }
            JOptionPane.showMessageDialog(this, 
                "Liste des fichiers mise à jour !", 
                "Succès", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Erreur de récupération : " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void downloadFile() {
        String fileName = (String) fileDropdown.getSelectedItem();
        if (fileName == null) {
            JOptionPane.showMessageDialog(this, 
                "Veuillez sélectionner un fichier à télécharger.",
                "Attention", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int port = 12347;
        try (Socket socket = new Socket("localhost", port);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream())) {

            out.writeUTF(fileName);

            File downloadedFile = new File("download/" + fileName);
            downloadedFile.getParentFile().mkdirs();

            try (BufferedOutputStream fileOut = new BufferedOutputStream(new FileOutputStream(downloadedFile))) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    fileOut.write(buffer, 0, bytesRead);
                }
            }

            JOptionPane.showMessageDialog(this, 
                "Fichier téléchargé avec succès !",
                "Succès", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur de téléchargement : " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteFile() {
        String fileName = (String) fileDropdown.getSelectedItem();
        if (fileName == null) return;

        int port = 12348;
        try (Socket socket = new Socket("localhost", port);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream())) {

            out.writeUTF(fileName);
            String response = in.readUTF();

            if ("SUCCESS".equals(response)) {
                JOptionPane.showMessageDialog(this, 
                    "Fichier supprimé avec succès !", 
                    "Succès", JOptionPane.INFORMATION_MESSAGE);
                fetchTransferredFiles();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "La suppression a échoué.", 
                    "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur de suppression : " + e.getMessage(), 
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(FileSenderClientGUI::new);
    }
}